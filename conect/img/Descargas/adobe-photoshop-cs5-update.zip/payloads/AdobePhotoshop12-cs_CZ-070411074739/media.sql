CREATE TABLE Branding ( ProductID TEXT NOT NULL REFERENCES Suites (ProductID),resource_type TEXT NOT NULL,resource_data TEXT NOT NULL,PRIMARY KEY (ProductID, resource_type) )
CREATE TABLE DependencyData( PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),PayloadIDb TEXT ,type TEXT NOT NULL ,product_family TEXT, product_name TEXT, version TEXT, PRIMARY KEY (PayloadID,PayloadIDb,type,product_family,product_name,version))
CREATE TABLE EULA_Files( productID TEXT NOT NULL, langCode TEXT NOT NULL,eula TEXT NOT NULL,PRIMARY KEY (productID, langCode) )
CREATE TABLE PayloadData( PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),domain TEXT NOT NULL,key TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY (PayloadID, domain, key) )
CREATE TABLE Payloads( PayloadID TEXT NOT NULL, payload_family TEXT NOT NULL,payload_name TEXT NOT NULL, payload_version TEXT NOT NULL,payload_type TEXT NOT NULL,PRIMARY KEY (PayloadID) )
CREATE TABLE SuitePayloads( ProductID TEXT NOT NULL REFERENCES Suites (ProductID),PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),PRIMARY KEY (ProductID, PayloadID) )
CREATE TABLE Suites( ProductID TEXT NOT NULL, group_name TEXT NOT NULL, group_family TEXT NOT NULL, display_name TEXT NOT NULL, PRIMARY KEY (ProductID) )
INSERT INTO DependencyData VALUES	("{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}", "{67A1ACB9-89FC-49EB-B3C0-7802F5348FC4}", "patch", "Photoshop", "Adobe Photoshop CS5 Check Language Pack_AdobePhotoshop12-cs_CZ", "")
INSERT INTO Payloads VALUES	("{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}", "Photoshop", "Adobe Photoshop CS5 Check Language Pack_12.0.4_AdobePhotoshop12-cs_CZ", "12.0.4", "patch")
INSERT INTO PayloadData VALUES("{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}", "0" , "PayloadInfo", '<PayloadInfo version="3.0.122.0"><BuildInfo>
    <Property name="Created">2011-04-07 07:47:39.685000</Property>
    <Property name="TargetName">AdobePhotoshop12-cs_CZ-070411074739</Property>
    <Property name="ProcessorFamily">All</Property>
  </BuildInfo><InstallerProperties>
    <Property name="payloadType">SQLite</Property>
    <Property name="AdobeCode">{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}</Property>
    <Property name="ProductName">Adobe Photoshop CS5 Check Language Pack</Property>
    <Property name="ProductVersion">12.0.4</Property>
  </InstallerProperties><InstallDir>
    <Platform isFixed="0" name="Default" folderName="">[AdobeProgramFiles]</Platform>
  </InstallDir><Languages languageIndependent="1"/><Satisfies>
    <ProductInfo>
      <Family>Photoshop</Family>
      <ProductName>Adobe Photoshop CS5 Check Language Pack_12.0.4_AdobePhotoshop12-cs_CZ</ProductName>
      <ProductVersion>12.0.4</ProductVersion>
    </ProductInfo>
  </Satisfies><Channel enable="1" id="AdobePhotoshopCS5CheckLanguagePack-12.0">
        <DisplayName>Adobe Photoshop CS5 Check Language Pack</DisplayName>
      </Channel><Update id="12.0.4">
        <DisplayName default="en_US">
          <en_US>Adobe Photoshop CS5 Check Language Pack 12.0.4</en_US>
        </DisplayName>
        <Description default="en_US">
          <en_US>Adobe Photoshop CS5 Check Language Pack</en_US>
        </Description>
      </Update><Extends type="patch">
    <ParentProductInfo>
      <Family>Photoshop</Family>
      <ProductName>Adobe Photoshop CS5 Check Language Pack_AdobePhotoshop12-cs_CZ</ProductName>
      <AdobeCode>{67A1ACB9-89FC-49EB-B3C0-7802F5348FC4}</AdobeCode>
    </ParentProductInfo>
  </Extends><InstallDestinationMetadata relocatableSize="6794376" sysDriveSize="0"><Destination>
      <Root>[INSTALLDIR]</Root>
      <TotalSize>6794376</TotalSize>
      <MaxPathComponent>/Adobe/AdobePatchFiles/{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}\16d5d81062cc4217a344668d23499bc5.rtp</MaxPathComponent>
    </Destination>
    <Assets>
      <Asset flag="1" name="Assets1_1" size="6794376"/>
    </Assets>
  </InstallDestinationMetadata><ConflictingProcesses>
    <Win32/>
  </ConflictingProcesses><AddRemoveInfo>
    <DisplayVersion>
      <Value lang="sq_AL">12.0.4</Value>
      <Value lang="ar_AE">12.0.4</Value>
      <Value lang="be_BY">12.0.4</Value>
      <Value lang="bg_BG">12.0.4</Value>
      <Value lang="ca_ES">12.0.4</Value>
      <Value lang="zh_CN">12.0.4</Value>
      <Value lang="zh_TW">12.0.4</Value>
      <Value lang="hr_HR">12.0.4</Value>
      <Value lang="cs_CZ">12.0.4</Value>
      <Value lang="da_DK">12.0.4</Value>
      <Value lang="nl_NL">12.0.4</Value>
      <Value lang="en_XC">12.0.4</Value>
      <Value lang="en_XM">12.0.4</Value>
      <Value lang="en_GB">12.0.4</Value>
      <Value lang="en_US">12.0.4</Value>
      <Value lang="et_EE">12.0.4</Value>
      <Value lang="fi_FI">12.0.4</Value>
      <Value lang="fr_FR">12.0.4</Value>
      <Value lang="fr_XM">12.0.4</Value>
      <Value lang="de_DE">12.0.4</Value>
      <Value lang="el_GR">12.0.4</Value>
      <Value lang="he_IL">12.0.4</Value>
      <Value lang="hu_HU">12.0.4</Value>
      <Value lang="hi_IN">12.0.4</Value>
      <Value lang="is_IS">12.0.4</Value>
      <Value lang="it_IT">12.0.4</Value>
      <Value lang="ja_JP">12.0.4</Value>
      <Value lang="ko_KR">12.0.4</Value>
      <Value lang="lv_LV">12.0.4</Value>
      <Value lang="lt_LT">12.0.4</Value>
      <Value lang="mk_MK">12.0.4</Value>
      <Value lang="nn_NO">12.0.4</Value>
      <Value lang="no_NO">12.0.4</Value>
      <Value lang="nb_NO">12.0.4</Value>
      <Value lang="pl_PL">12.0.4</Value>
      <Value lang="pt_BR">12.0.4</Value>
      <Value lang="ro_RO">12.0.4</Value>
      <Value lang="ru_RU">12.0.4</Value>
      <Value lang="sh_YU">12.0.4</Value>
      <Value lang="sk_SK">12.0.4</Value>
      <Value lang="sl_SI">12.0.4</Value>
      <Value lang="es_QM">12.0.4</Value>
      <Value lang="es_ES">12.0.4</Value>
      <Value lang="sv_SE">12.0.4</Value>
      <Value lang="th_TH">12.0.4</Value>
      <Value lang="tr_TR">12.0.4</Value>
      <Value lang="uk_UA">12.0.4</Value>
      <Value lang="vi_VN">12.0.4</Value>
      <Value lang="fr_CA">12.0.4</Value>
      <Value lang="es_MX">12.0.4</Value>
    </DisplayVersion>
    <DisplayName>
      <Value lang="sq_AL">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="ar_AE">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="be_BY">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="bg_BG">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="ca_ES">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="zh_CN">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="zh_TW">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="hr_HR">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="cs_CZ">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="da_DK">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="nl_NL">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="en_XC">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="en_XM">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="en_GB">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="en_US">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="et_EE">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="fi_FI">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="fr_FR">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="fr_XM">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="de_DE">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="el_GR">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="he_IL">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="hu_HU">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="hi_IN">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="is_IS">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="it_IT">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="ja_JP">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="ko_KR">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="lv_LV">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="lt_LT">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="mk_MK">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="nn_NO">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="no_NO">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="nb_NO">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="pl_PL">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="pt_BR">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="ro_RO">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="ru_RU">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="sh_YU">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="sk_SK">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="sl_SI">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="es_QM">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="es_ES">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="sv_SE">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="th_TH">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="tr_TR">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="uk_UA">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="vi_VN">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="fr_CA">Adobe Photoshop CS5 Check Language Pack</Value>
      <Value lang="es_MX">Adobe Photoshop CS5 Check Language Pack</Value>
    </DisplayName>
  </AddRemoveInfo><UserPreferences>0</UserPreferences></PayloadInfo>')
INSERT INTO PayloadData VALUES("{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}", "0", "ChannelID", "AdobePhotoshopCS5CheckLanguagePack-12.0")
INSERT INTO PayloadData VALUES("{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}", "0", "ChannelInfo", '<Channel enable="1" id="AdobePhotoshopCS5CheckLanguagePack-12.0">
        <DisplayName>Adobe Photoshop CS5 Check Language Pack</DisplayName>
      </Channel>')
INSERT INTO PayloadData VALUES("{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}", "0", "UpdateID", "12.0.4")
INSERT INTO PayloadData VALUES("{F8088B2E-D9FC-4D84-B9E2-5161693DDC46}", "0", "UpdateInfo", '<Update id="12.0.4">
        <DisplayName default="en_US">
          <en_US>Adobe Photoshop CS5 Check Language Pack 12.0.4</en_US>
        </DisplayName>
        <Description default="en_US">
          <en_US>Adobe Photoshop CS5 Check Language Pack</en_US>
        </Description>
      </Update>')
